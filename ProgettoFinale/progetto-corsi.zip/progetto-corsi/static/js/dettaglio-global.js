document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Animazione Barre di Avanzamento
    const progressFills = document.querySelectorAll('.progress-fill');
    
    // Funzione per avviare l'animazione quando l'elemento è visibile
    const animateBars = () => {
        progressFills.forEach(bar => {
            const target = bar.getAttribute('data-percent');
            bar.style.width = target + '%';
        });
    };

    // Simuliamo un piccolo ritardo per l'effetto visivo al caricamento
    setTimeout(animateBars, 500);

    // 2. Effetto Parallasse su Immagine Hero durante lo scroll
    window.addEventListener('scroll', () => {
        const scrollValue = window.scrollY;
        const heroImg = document.querySelector('.hero-image');
        const overlay = document.querySelector('.image-overlay');

        if (heroImg) {
            heroImg.style.transform = `scale(${1 + scrollValue / 2000})`;
            overlay.style.opacity = 1 - scrollValue / 600;
        }
    });

    // 3. Conferma Iscrizione (Interazione aggiuntiva)
    const enrollButtons = document.querySelectorAll('.btn-enroll');
    enrollButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const session = btn.closest('.session-card').querySelector('p').innerText;
            alert("Richiesta di iscrizione inviata con successo!\nSessione: " + session);
            btn.innerText = "In attesa...";
            btn.style.backgroundColor = "#64748b";
            btn.disabled = true;
        });
    });
});