document.addEventListener('scroll', () => {
    const videoOverlay = document.querySelector('.video-overlay');
    const scrollValue = window.scrollY;
    
    // Calcoliamo l'opacità in base allo scroll (max 0.9)
    let opacityValue = 0.6 + (scrollValue / 1000);
    if(opacityValue > 0.9) opacityValue = 0.9;
    
    videoOverlay.style.backgroundColor = `rgba(30, 41, 59, ${opacityValue})`;
    
    // Effetto parallasse leggero sul testo del video
    const title = document.querySelector('.video-overlay h1');
    title.style.transform = `translateY(${scrollValue * 0.3}px)`;
});